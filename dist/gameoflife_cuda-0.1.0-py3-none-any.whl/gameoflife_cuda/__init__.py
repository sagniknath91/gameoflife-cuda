from .gameoflife_cuda import initialize_grid, update, device
